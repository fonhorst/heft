Reporting a Bug
===============

You can report a bug on the issue list on google code.

`<http://code.google.com/p/deap/issues/list>`_

For simple questions, contact us on the deap users group. 

`<http://groups.google.com/group/deap-users>`_
